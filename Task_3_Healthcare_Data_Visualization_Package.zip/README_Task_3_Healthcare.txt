TASK 3: COMPLETE CODE WITH VISUALIZATION GRAPHS
Project: Healthcare Data Analytics for Disease Prediction

How to run:
1. Open Google Colab: https://colab.research.google.com/
2. Create a new notebook.
3. Copy the code from Task_3_Healthcare_Data_Visualization.py into a cell,
   or upload/open the script in an environment that supports Google Colab.
4. Download the CSV dataset from:
   https://www.kaggle.com/datasets/prasad22/healthcare-dataset
5. Run the code and upload the CSV when prompted.

The script includes:
- Duplicate removal and missing-value handling
- Text cleaning and categorical label encoding
- Missing-values check graph
- Medical-condition category bar chart
- Patient age histogram
- Gender distribution pie chart
- Billing amount histogram (when available)
- Correlation heatmap
- Export of cleaned data and label mappings

Note: Graphs depend on the columns present in the uploaded CSV. This is data
analysis for an academic project, not a clinical diagnostic tool.
